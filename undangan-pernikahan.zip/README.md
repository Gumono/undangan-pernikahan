# Undangan Pernikahan Online - Rina & Budi

Selamat datang di undangan pernikahan online kami. Website ini berisi:

- Informasi acara
- Pemutar musik
- Galeri foto kenangan

### Cara Melihat
Buka link GitHub Pages setelah mengaktifkan Pages di repository ini.

### Struktur Folder
```
- index.html
- style.css
- script.js
- musik-pernikahan.mp3
- foto1.jpg
- foto2.jpg
- ...
```

Terima kasih atas doa dan restunya!
