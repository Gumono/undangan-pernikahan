// Tambahkan animasi musik atau efek galeri jika diperlukan nanti
console.log('Undangan Pernikahan Rina & Budi aktif!');
